const Message = require('../Models/message')
const Chat = require('../Models/chat')

module.exports = {
    create: async(req, res) => {
        const { title } = req.body
        const newChat = await Chat.create({
            title
        })
        return res.send(newChat)
    },
    // load: async (req, res) => {
    //     const chats = await Chat.find ()
    //     res.json (chats)
    // }
}