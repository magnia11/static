const Message = require('../Models/message')
const Chat = require('../Models/chat')

module.exports = {
    send: async(req, res) => {
        try {
            const { chatId, sender, text } = req.body
            const newMsg = await Message.create({
                chatId, sender, text
            })
            return res.send(JSON.stringify({status: 1}))
        }
        catch(err) {
            console.log(err)
            return res.send(JSON.stringify({status: 0, err: err}))
        }
    },
    load: async (req, res) => {
        const messages = await Message.find ()
        res.json (messages)
    }
}