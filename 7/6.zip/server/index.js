const mongoose = require('mongoose')
// const Message = require ('./models/message')
const Message = require ('./controlers/messages')

const express = require ('express')
const app = express ()

app.use(express.json())
mongoose.Promise = global.Promise

mongoose.connect('mongodb://localhost/reactgram-v1', { useNewUrlParser: true, useUnifiedTopology: true})
.then(() => {
    console.log('ok')
})
.catch(() => {
    console.log('error DB')
})

app.post('/message', Message.send)

app.get('/messages', Message.load)


app.listen (3300, () => {
    console.log ('running at 3300')
})