import { RSAA, getJSON } from 'redux-api-middleware';

export let SEND_MSG = '@@messages/SEND_MSG'
export const START_MESSAGES_LOADING = '@@message/START_MESSAGES_LOADING';
export const SUCCESS_MESSAGES_LOADING = '@@message/SUCCESS_MESSAGES_LOADING';
export const ERROR_MESSAGES_LOADING = '@@message/ERROR_MESSAGES_LOADING';

export let sendMessage = (messageId, sender, text) => ({
    type: SEND_MSG,
    messageId: messageId,
    sender: sender,
    text: text
})

export let send = (message) => {
    return dispatch => {
        dispatch(fetchProductsPending());

    }
}

export let loadMessages = () => ({
   [RSAA]: {
       endpoint: '/api/messages',
       method: 'GET',
       types: [
           START_MESSAGES_LOADING,
           {
               type: SUCCESS_MESSAGES_LOADING,
               payload: (action, state, res) => getJSON(res)
                            .then(json => {
                                console.log(json)
                                return json
                            }),
           },
           ERROR_MESSAGES_LOADING,
       ],
   },
});