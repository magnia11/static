import React, {Component} from 'react';
import ReactDom from 'react-dom';

import Message from '../Message/Message.jsx'

//actions
import { sendMessage, send, loadMessages } from '../../store/actions/messages_actions.js'

//redux
import { bindActionCreators } from 'redux'
import connect from 'react-redux/es/connect/connect'

class Messages extends Component {
    constructor(props) {
        super(props)
        this.state = {
            msg: '',
            show: false
        }
    }
    //methods
    sendMessage = (text, sender) => {
        const { messages } = this.props
        const messageId = Object.keys(messages).length + 1;

        this.props.sendMessage(messageId, sender, text)
    }

    handleSendMessage = (text, sender) => {
        let { send } = this.props;
        let message = {
            sender: 'Darth',
            text: this.state.msg,
            chatId: '1',
            messages: []
        }

        fetch('api/message', {
            method: 'POST',
            body: JSON.stringify(message),
            headers: {
                'Content-Type': 'application/json'
            }
        })

        this.setState({ msg: '' })
        if (sender == 'Darth') {
            this.sendMessage(text, sender)
        }
    }

    handleChange = (evt) => {
        if (evt.keyCode !== 13) {
            this.setState ({msg: evt.target.value})
        }
    }
    
    handle = () => {
        this.setState({ show: !this.state.show })
    }

    componentDidMount() {
        console.log('загрузка пошла')
        this.props.loadMessages()
    }
    render() {
        //let user = this.props.usr
        let usr = 'Darth'
        // let { messages } = this.props
        let { messages } = this.props
        let MessagesArr = []
        
        messages.forEach(msg => {
            MessagesArr.push(<Message 
                sender={ msg.user } 
                text={ msg.text }
                key={ msg._id }
            />)
        })

        return (
            <div className="wrapper">
                <h2>ReactGram &copy;</h2>
                <p>Hello { usr }!</p>
                <div>
                    { MessagesArr }
                </div>
                <input type="text" 
                onChange = { this.handleChange } 
                // onKeyUp = { this.handleChange }
                value = { this.state.msg }/>
                <button onClick = { () => this.handleSendMessage (this.state.msg, 'Darth') }>Send</button>
            </div>
        )
    }
}

const mapStateToProps = ({ msgReducer }) => ({
    messages: msgReducer.messages
})

const mapDispatchToProps = dispatch => bindActionCreators( { sendMessage, send, loadMessages  }, dispatch )

export default connect(mapStateToProps, mapDispatchToProps)(Messages)
